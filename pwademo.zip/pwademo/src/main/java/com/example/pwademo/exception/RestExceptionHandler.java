package com.example.pwademo.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import com.example.pwademo.exception.PatientNotFoundException;
import com.example.pwademo.model.ErrorModel;
import com.example.pwademo.exception.IdAlreadyExistException;

@RestControllerAdvice
public class RestExceptionHandler {

	@ExceptionHandler(PatientNotFoundException.class)
    private ResponseEntity<ErrorModel> handleEntityNotFound(PatientNotFoundException ex){
        ErrorModel error = new ErrorModel(HttpStatus.NOT_FOUND, "Patient Not Found", ex.getMessage());

        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }
	
	@ExceptionHandler(IdAlreadyExistException.class)
	private ResponseEntity<ErrorModel> handleIdAlreadyExist(IdAlreadyExistException ex){
		ErrorModel error = new ErrorModel(HttpStatus.CONFLICT,"Id Already Exist",ex.getMessage());
		return new ResponseEntity<>(error, HttpStatus.CONFLICT);
	}
}
