package com.example.pwademo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.pwademo.service.PatientServices;
import com.example.pwademo.exception.IdAlreadyExistException;
import com.example.pwademo.exception.PatientNotFoundException;
import com.example.pwademo.entity.PatientEntity;


@RestController
@RequestMapping("/api/v1")
@CrossOrigin
public class PatientController {

	@Autowired
	private final PatientServices patientServices;
	
	 public PatientController(PatientServices patientServices) {
	        this.patientServices = patientServices;
	    }
	 
	@GetMapping
    public List<PatientEntity> GetPatientAll() {
        return patientServices.findAllPatient();
    }
	
	@GetMapping("/{id}")
    public PatientEntity GetPatientById(@PathVariable("id") Long id) throws PatientNotFoundException {
        return patientServices.findById(id);
    }
	
	@PostMapping
    public PatientEntity savePatient(@RequestBody PatientEntity patientEntity) throws IdAlreadyExistException{
        return patientServices.savePatient(patientEntity);
    }
	
	@PutMapping("/{id}")
    public PatientEntity EditPatientById(@PathVariable("id") Long id,@RequestBody PatientEntity patientEntity) throws PatientNotFoundException{
        return patientServices.updatePatient(id , patientEntity);
    }
    
	@DeleteMapping("/{id}")
    public String DeletePatientDetails(@PathVariable("id") Long id) throws PatientNotFoundException{
		patientServices.deletePatient(id);
		return "Delete Done";
		
	}
    
	
}
