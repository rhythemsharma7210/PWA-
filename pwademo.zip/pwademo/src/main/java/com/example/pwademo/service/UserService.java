package com.example.pwademo.service;

import org.springframework.stereotype.Service;

import com.example.pwademo.repository.UserRepository;


import com.example.pwademo.entity.UserEntity;

@Service
public class UserService {

 private final UserRepository userRepository;
	 
	 public UserService(UserRepository userRepository) {
	        this.userRepository = userRepository;
	    }
	 
	 public boolean UserLogin(UserEntity userEntity) {
		 
		 UserEntity userfind = userRepository.findById(userEntity.getId()).get();
		 
		 System.out.println(userfind.getId() + userEntity.getId() + userfind.getPassword() + userEntity.getPassword());
		 
		 if(userfind.getId().equalsIgnoreCase(userEntity.getId()) && userfind.getPassword().equalsIgnoreCase(userEntity.getPassword())) {
			 return true;
		 }
		 else
			 return false;
		 
	 }
	 
	
}
