package com.example.pwademo.exception;

public class IdAlreadyExistException extends Exception {

	public IdAlreadyExistException(String msg) {
		super(msg);
	}
	
}
