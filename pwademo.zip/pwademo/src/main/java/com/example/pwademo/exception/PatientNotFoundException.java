package com.example.pwademo.exception;

public class PatientNotFoundException extends Exception{

	public PatientNotFoundException(String msg) {
		super(msg);
	}

}
