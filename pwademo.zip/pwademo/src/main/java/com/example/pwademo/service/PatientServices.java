package com.example.pwademo.service;


import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.pwademo.entity.PatientEntity;

import com.example.pwademo.repository.PatientRepository;
import com.example.pwademo.exception.PatientNotFoundException;
import com.example.pwademo.exception.IdAlreadyExistException;


@Service
public class PatientServices {

	
	 private final PatientRepository patientRepository;
	 
	 public PatientServices(PatientRepository patientRepository) {
	        this.patientRepository = patientRepository;
	    }
	 
	 
	 public List<PatientEntity> findAllPatient() {
	        return patientRepository.findAll();
	    }
	 
	 public PatientEntity findById(Long id) throws PatientNotFoundException{
	        Optional<PatientEntity> patientEntity = patientRepository.findById(id);
	        if(patientEntity.isEmpty()) {
	        	throw new PatientNotFoundException("Patient Not Found");
	        }
	    	return patientEntity.get();
	    }
	 
	 
	 public PatientEntity savePatient(PatientEntity patientEntity) throws IdAlreadyExistException{
		 	if(patientEntity.getId() != null) {
		 		if(patientRepository.findById(patientEntity.getId()).get() != null) {
		 			throw new IdAlreadyExistException("data with this id already exist");
		 		}else
		 			return patientRepository.save(patientEntity);
		 	}
		 		return patientRepository.save(patientEntity);
	        
	    }
	 
	 
	 public PatientEntity updatePatient(Long id , PatientEntity patientEntity) throws PatientNotFoundException {
		 
		 Optional<PatientEntity> patientFind = patientRepository.findById(id);
		 
		 if(patientFind.isEmpty()) {
			 throw new PatientNotFoundException("Patient Not Found");
		 }
		 
		 patientFind.get().setAddress(patientEntity.getAddress());
		 patientFind.get().setDisease(patientEntity.getDisease());
		 patientFind.get().setEmail(patientEntity.getEmail());
		 patientFind.get().setFirstName(patientEntity.getFirstName());
		 patientFind.get().setLastName(patientEntity.getLastName());
		 patientFind.get().setPhone(patientEntity.getPhone());
		 
		 return patientFind.get();
	 }
	 
	 
	  public void deletePatient(Long id) throws PatientNotFoundException{
		  Optional<PatientEntity> patientEntity = patientRepository.findById(id);
		  if(patientEntity.isEmpty()) {
	        	throw new PatientNotFoundException("Patient Not Found");
	        }
	        patientRepository.deleteById(id);
	    }
}
