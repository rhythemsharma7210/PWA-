console.log("From service worker")

self.addEventListener("install", event => {
    event.waitUntil(
        caches.open("appcache1").then((cache) => {
            cache.addAll([
                "http://localhost:3000/",
                "http://localhost:3000/home",
                "http://localhost:3000/patient",
                "http://localhost:3000/static/js/bundle.js",
                "http://localhost:3000/manifest.json",
                "http://localhost:3000/favicon.ico",
                "http://localhost:3000/ws",
                "http://localhost:3000/logo192.png",
                "https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"

            ]);
        })
    )
})

self.addEventListener("fetch", event => {
    if (!navigator.onLine) {
        console.log("event")
        event.respondWith(
            caches.match(event.request).then(result => {
                if (result) return result;
            })
        )
    }
    else{
        console.log("online mode")
    }
})

self.addEventListener("sync",event=>{
    console.log("Online back");
})