// Service Worker Registered
export default function registerServiceWorker(){
    if (navigator.serviceWorker) {
        navigator.serviceWorker.register(`${process.env.PUBLIC_URL}/sw.js`).then((res) => {
            console.log("The service worker registered : ");
        })
    }
}
