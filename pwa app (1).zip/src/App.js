import React, { useEffect } from 'react';
import logo from './logo.svg';
import './App.css';
import Home from './components/Home';
import About from './components/About';
import Login from './components/Login';
import Edit from './components/Edit';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import AddPatient from './components/AddPatient';
import UsersData from './db/UsersData';

function App() {
  

  useEffect(()=>{
    // console.log("Calling get connection");
    // UsersData.getConnection()
  })
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<Login></Login>}></Route>
        <Route path='/home' element={<Home></Home>}></Route>
        <Route path='/about' element={<About></About>}></Route>
        <Route path='/patient' element={<AddPatient></AddPatient>}></Route>
        <Route path='/Edit' element={<Edit></Edit>}></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
