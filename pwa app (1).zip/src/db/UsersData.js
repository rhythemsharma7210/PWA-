class UsersData {

    constructor(){
        var db;
    }

    getConnection() {
        var idb = window.indexedDB;
        var request = idb.open("pwa-db", 4);

        request.onerror = event => {
            console.log("error");
        }

        request.onupgradeneeded = event => {
            const db = request.result;

            if (db.objectStoreNames.contains("users")) {
                console.log("Table exists");
            }
            else {
                db.createObjectStore("users", {
                    keyPath: "id"
                })

                console.log("Table created");
            }

            if(db.objectStoreNames.contains("new-users")){
                console.log("New Users table exit");
            }
            else{
                db.createObjectStore("new-users" , {
                    keyPath : "id"
                })
            }

        }

        request.onsuccess = event => {
            this.db = request.result;
        }
    }

    closeConnection(){
        this.db.close()
    }

    saveUserData(data) {
        // console.log(this.db);
        const tx = this.db.transaction("users", "readwrite");
        const userData = tx.objectStore("users");
        // console.log(this.db);
        const users = userData.put(data);
        users.onsuccess = event => {
            // console.log("Data added");
            // this.db.close()
        }
    }

    deleteAllUserData(data) {
        // console.log(this.db);
        const tx = this.db.transaction("users", "readwrite");
        const userData = tx.objectStore("users");
        const users = userData.clear()
        return new Promise((resolve,reject)=>{
            users.onsuccess= event=>{
                resolve("Deleted");
            }
            users.onerror = event=>{
                reject(new Error("Unable to Delete"))
            }
        })
    }

    getAllUsers(){
        const tx = this.db.transaction("users", "readonly");
        const usersData = tx.objectStore("users");
        // console.log(this.db);
        const users = usersData.getAll();

        return new Promise((resolve,reject)=>{
            users.onsuccess= event=>{
                resolve(event.target.result);
            }

            users.onerror = event=>{
                reject(new Error("Unable to fetch locally"))
            }
        })
    
    }

   

    // getLastId(){
    //     const tx = this.db.transaction("users", "readonly");
    //     const usersData = tx.objectStore("users");
    //     // console.log(this.db);
    //     const users = usersData.getAll();

    //     return new Promise((resolve,reject)=>{
    //         users.onsuccess= event=>{
    //             console.log("In last Id:")
    //             console.log(event.target.result)
    //             var res = event.target.result;
    //             console.log("res:"+res[5])
    //             resolve();
    //         }

    //         users.onerror = event=>{
    //             reject(new Error("Unable to fetch last Id"))
    //         }
    //     })

    // }

    deleteUsersData(id){
        const tx = this.db.transaction("users", "readwrite");
        const usersData = tx.objectStore("users");
        // console.log(this.db);
        const tx1 = this.db.transaction("new-users" , "readwrite");

        const userData1 = tx1.objectStore("new-users");

        const users = usersData.delete(id)

        const users1 = userData1.delete(id);

        return new Promise((resolve,reject)=>{
            users.onsuccess= event=>{
                resolve("Deleted");
            }

            users.onerror = event=>{
                reject(new Error("Unable to Delete"))
            }
        })
    }

    saveNewUserData(data){
        const tx = this.db.transaction("new-users" , "readwrite");

        const userData = tx.objectStore("new-users");

        const user = userData.put(data);

        return new Promise((resolve , reject )=>{
            user.onsuccess = event =>{
                resolve("Data Added")
            }

            user.onerror = event =>{
                reject("Data not added")
            }
        })
    }

    getAllNewUsers(){
        console.log(this.db);
        console.log("Get all new users");
        // this.getConnection()
        

        const tx = this.db.transaction("new-users", "readonly");
        const usersData = tx.objectStore("new-users");

        const users = usersData.getAll();

        return new Promise((resolve,reject)=>{
            users.onsuccess= event=>{
                resolve(event.target.result);
            }

            users.onerror = event=>{
                reject(new Error("Unable to fetch locally"))
            }
        })
        

    }

    deleteNewUsers(id){
        console.log("Delete all new users");
        
        const tx = this.db.transaction("new-users", "readwrite");
        const usersData = tx.objectStore("new-users");

        const users = usersData.delete(id)

        return new Promise((resolve,reject)=>{
            users.onsuccess= event=>{
                resolve("All new users deleted");
            }

            users.onerror = event=>{
                reject(new Error("No new users deleted"))
            }
        })
        
    }


    getOneUsertf(id){
        const tx = this.db.transaction("new-users", "readwrite");
        const usersData = tx.objectStore("new-users");
        const users = usersData.get(id);
        return new Promise((resolve,reject)=>{
            users.onsuccess= event=>{
                resolve("true");
            }

            users.onerror = event=>{
                reject("false")
            }
        })


    }



}

export default new UsersData();