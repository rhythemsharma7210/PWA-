import { Link, useNavigate } from "react-router-dom";
import UsersData from "../db/UsersData";
import styles from "./Navbar.module.css"

function Navbar() {
    const navigate = useNavigate();

    return ( 
        <div className="container-fluid">
            <nav style={styles.nav}>
                <ul className={styles.nav_ul}>
                    <Link to={"/home"}><li>Get Patients</li></Link>
                    <Link to={"/patient"}><li>Add patient</li></Link>
                    <button className="btn btn-danger"
                    style={{
                        position: "fixed",
                        right: "10px",
                        top: "10px"}}
                        onClick={()=>{
                            localStorage.removeItem("login");
                            navigate("/")
                    }}>Logout</button>
                </ul>
            </nav>
        </div>
     );
}

export default Navbar;