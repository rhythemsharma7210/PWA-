import logo from "./images/logo192.png"
import { useEffect, useState } from "react";
import UsersData from "../db/UsersData";
import Navbar from "./Navbar";
import { AiFillEdit, AiFillDelete } from 'react-icons/ai'
import { FiRefreshCw } from 'react-icons/fi'
import { Table, Thead, Tbody, Tr, Th, Td } from 'react-super-responsive-table';
import 'react-super-responsive-table/dist/SuperResponsiveTableStyle.css';

import styles from "./Home.module.css"
import swal from "sweetalert";
import { useNavigate } from "react-router-dom";

function Home() {
    const [isoffline, setisoffline] = useState(false);
    const [data, setData] = useState([])
    const [loadData, setloadData] = useState(true);
    const [message, setmessage] = useState("You are offline");
    const [colortr, setColortr] = useState("#00FF00");
    const [newUser , setnewUser] = useState([]);
    const [Redoo , setRedoo ] = useState(false);
    const navigate = useNavigate()



    useEffect(() => {
        UsersData.getConnection()

        if (!navigator.onLine)   setisoffline(true)
            else setisoffline(false)

        fetch("http://localhost:8080/api/v1").then(res => {
            return res.json()
        }).then(emps => {

            UsersData.deleteAllUserData(65).then(data => console.log(data)).catch(err => console.log(err))
            setData(emps)
            setisoffline(false)
            emps.forEach(element => {
                UsersData.saveUserData(element);
            });

            // UsersData.closeConnection()
        }).catch(err => {
            if (navigator.onLine) {
                setmessage("Unable to fetch from server")
            }
            else {
                setmessage("You are Offline")
            }
            setisoffline(true);
            UsersData.getAllUsers().then(data => {
                setData(data)
            }).catch(err => {
                console.log(err);
            }
            )

            UsersData.getAllNewUsers().then(data => {
                setnewUser(data)
            }).catch(err => {
                console.log(err);
            }
            )

            console.log("Fetching in offline mode")
        })
    }, [loadData,isoffline])

    function handleSync() {
        if (navigator.onLine) {
            console.log("User is online");
            UsersData.getAllNewUsers().then(data => {
                data.forEach(element => {
                    console.log(element);
                    var newPatient = {
                        firstName : element.firstName,
                        lastName : element.lastName,
                        email : element.email,
                        address : element.address,
                        phone : element.phone,
                        disease : element.disease
                    }
                    fetch("http://localhost:8080/api/v1", {
                        method: "POST",
                        body: JSON.stringify(newPatient),
                        headers: {
                            "Content-type": "application/json"
                        }
                    }).then(data => {
                        UsersData.deleteNewUsers(element.id)
                        const user = newUser.filter(data=>{
                            return data.id !== element.id;
                        })
                        setnewUser(user)
                        setRedoo(false);
                    }).catch(err => {
                        console.log(err);
                        setRedoo(true);
                    })


                });
            })
            if(Redoo === false ){
                setnewUser([])
            }

            if (localStorage.getItem("deleteUserId")) {
                var arr = JSON.parse(localStorage.getItem("deleteUserId"))
                arr.forEach(id => {
                    fetch(`http://localhost:8080/api/v1/${id}`, {
                        method: "DELETE"
                    }).then(data => {
                        var arr = JSON.parse(localStorage.getItem("deleteUserId"))
                        arr = arr.filter(pid=>pid!==id)
                        localStorage.setItem("deleteUserId", JSON.stringify(arr))
                    }).catch(err=>{})
                })

                if(JSON.parse(localStorage.getItem("deleteUserId"))===0) localStorage.clear()
                

            }

            setloadData(!loadData)
        }
        else {
            console.log("Offline sync");
            setisoffline(true)
            setloadData(!loadData)
        }
    }

    function handleDelete(id) {
        console.log("Deleted Id : " + id)
        if (navigator.onLine) {
            fetch(`http://localhost:8080/api/v1/${id}`, {
                method: "DELETE"
            }).then(data => {
                swal({
                    title: "Deleted!!",
                    text: `Patient record with ID ${id} is deleted`,
                    icon: "success"
                }).then(val => {
                    handleSync()
                })
            })
            return
        }
        else {
            UsersData.deleteUsersData(id).then(data => {
                swal({
                    title: "Deleted!!",
                    text: `Patient record with ID ${id} is deleted`,
                    icon: "success"
                }).then(val => {
                    if (localStorage.deleteUserId) {
                        var arr = JSON.parse(localStorage.getItem("deleteUserId"))
                        arr.push(id)
                        localStorage.setItem("deleteUserId", JSON.stringify(arr))
                    }
                    else {
                        localStorage.setItem("deleteUserId", JSON.stringify([id]))
                    }
                    handleSync()
                })
            })
        }
    }



    return (
        <div className="container h-100">
            <div className="col-md-7 mx-auto mt-5 pb-5">

                <Navbar></Navbar>
                <h1 className="text-center text-uppercase" style={{ color: "#4441ec" }}>Patient <span style={{ color: "#c94a4c" }}>Details</span></h1>
                {isoffline && <div className="alert alert-warning text-center" role="alert">{message}</div>}
                {/* <div class="alert alert-warning" role="alert">Hello</div> */}
                <div className="p-3 bg-light">
                    <button className={`btn btn-outline-none ${styles.refresh}`} style={{ position: "absolute" }} onClick={handleSync}><FiRefreshCw></FiRefreshCw></button>
                    <Table className="table table-light table-striped table-responsive"> 

                        <Thead className="thead-dark">
                            <Tr>
                                
                                <Th>Id</Th>
                                <Th>Name</Th>
                                <Th>Email</Th>
                                <Th>Number</Th>
                                <Th>Diseases</Th>
                                <Th colSpan="2">Action</Th>
                            </Tr>
                        </Thead>
                        <Tbody>
                            {/* {console.log("the second data ",typeof(data))} */}
                            {data.map(emp => {
                                //  console.log("the emp is : " , emp.id);
                                
                                
                                return <Tr key={emp.id} style={{'background-color' : {colortr}  }}> 
                                    <Td>{emp.id}</Td>
                                    <Td>{emp.firstName + " " + emp.lastName}</Td>
                                    <Td>{emp.email}</Td>
                                    <Td>{emp.phone}</Td>
                                    <Td>{emp.disease}</Td>
                                    {/* <Td className={styles.action}><AiFillEdit></AiFillEdit></Td> */}
                                    <Td className={styles.action} onClick={() => handleDelete(emp.id)}><AiFillDelete></AiFillDelete></Td>
                                </Tr>
                            })}

                        {newUser.map(emp => {
                                //  console.log("the emp is : " , emp.id);
                                
                                
                                return <Tr key={emp.id} style={{ backgroundColor : " rgb(244 208 195 / 94%)"}}> 
                                    <Td>{emp.id}</Td>
                                    <Td>{emp.firstName + " " + emp.lastName}</Td>
                                    <Td>{emp.email}</Td>
                                    <Td>{emp.phone}</Td>
                                    <Td>{emp.disease}</Td>
                                    {/* <Td className={styles.action}><AiFillEdit></AiFillEdit></Td> */}
                                    <Td className={styles.action} onClick={() => handleDelete(emp.id)}><AiFillDelete></AiFillDelete></Td>
                                </Tr>
                            })}
                        </Tbody>
                    </Table>
                </div>
            </div>

        </div>


    );
}

export default Home;