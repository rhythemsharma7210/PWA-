import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import UsersData from "../db/UsersData";

function Login() {

    const [email, setemail] = useState("");
    const [password, setpassword] = useState("");
    const [error, seterror] = useState();
    const [savelogin,setSaveLogin] = useState();
    const navigate = useNavigate()

    function handleEmailChange(event) {
        setemail(event.target.value)
    }

    function handlePassChange(event) {
        setpassword(event.target.value)
    }

    
    UsersData.getConnection();
    useEffect(()=>{
        if(localStorage.getItem("login")){
            navigate("/home");
        }
        
    },[savelogin])

    function handleSubmit(event) {
        event.preventDefault()
        console.log(email + " " + password);
        const user = {
            id: email,
            password: password
        }

        fetch("http://localhost:8080/api/v2", {
            method: "POST",
            body: JSON.stringify(user),
            headers: {
                "Content-type": "application/json"
            }
        }).then(res => res.json()).then(data => {
            console.log(data);
            if (data === true) {
                localStorage.setItem("login",true);
                console.log("Trueeeeeeeee");
                navigate("/home")
            }

            seterror("Invalid Credentials")


        }).catch(err => {
            // console.log(err);
            UsersData.getLoginUser(email).then(data=>{
                if(password===data.password) navigate("/home")
                else seterror("Invalid Credentials")
            }).catch(err=>{
                seterror(err)
                console.log("The err" +err);
            })
        })
    }

    return (
        <div className="container-fluid h-100">
            <div className="row h-100" style={{ alignItems: "center" }}>
                <div className="col-md-4 mx-auto mt-5">
                    <div className="card" >
                        <div className="card-header text-center">
                            <h2 className="text-uppercase font-weight-bold">Login</h2>
                        </div>
                        <div className="card-body">
                            <form onSubmit={handleSubmit}>
                                <div className="form-group">
                                    <label htmlFor="">Email Id </label>
                                    <input type="email" onChange={handleEmailChange} name="id" className="form-control" ></input>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="">Password </label>
                                    <input type="password" onChange={handlePassChange} name="password" className="form-control" ></input>
                                </div>
                                {error && <p className="text-center text-danger">{error}</p>}
                                <input type="submit" value="Login" className="btn btn-primary btn-block"></input>

                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    );
}

export default Login;