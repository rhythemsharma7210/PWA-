import { useState } from "react";
import { useNavigate } from "react-router-dom";
import swal from "sweetalert";
import UsersData from "../db/UsersData";
import Navbar from "./Navbar";
import styles from "./Navbar.module.css"

function AddPatient() {

    const [fname, setfname] = useState();
    const [lname, setlname] = useState();
    const [email, setemail] = useState();
    const [address, setaddress] = useState();
    const [number, setnumber] = useState();
    const [disease, setdisease] = useState();
    const [validation,setValidation] = useState("is-valid");
   
    const [patternValid, setPatternValid] = useState('')
    const [patternValidE, setPatternValidE] = useState('')
    const [patternValidFirstName, setPatternValidFirstName] = useState('')
    const [patternValidLastName, setPatternValidLastName] = useState('')
    const [patternValidNumber, setPatternValidNumber] = useState('')
  

    const [error, seterror] = useState();

    const navigate = useNavigate()

    UsersData.getConnection()

    function handleFName(event) {
        setfname(event.target.value);
    }
    function handleLName(event) {
        setlname(event.target.value);
    }
    function handleEmail(event) {
        setemail(event.target.value);
    }
    function handleAddress(event) {
        setaddress(event.target.value);
    }
    function handleDisease(event) {
        setdisease(event.target.value);
    }
    function handleNumber(event) {
        setnumber(event.target.value);
    }

    
  const isvalidEmail = (username) => {
    const pattern = /[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$/
    return pattern.test(username);
  }
  
  const isEmailValid = () => {
    const isEValid = email && isvalidEmail(email)
    setPatternValidE(isEValid ? '' : 'Invalid Email')
    //document.getElementById("emailHelpBlock").innerText="hiii";
  }
  
  const isvalidName = (name) => {
    const pattern = /^[a-zA-z\s]*$/
    return pattern.test(name);
  }
  
  const isFirstNameValid = () => {
    const isNameValid = fname && isvalidName(fname)
    setPatternValidFirstName(isNameValid ? '' : 'Should  contain letters')
  }
  
  const isLastNameValid = () => {
    const isNameValid = lname && isvalidName(lname)
    setPatternValidLastName(isNameValid ? '' : 'Should contain letters')
  }
  
  const isvalidNumber = (name) => {
    const pattern = /^\d{10}$/
    return pattern.test(name);
  }
  
  const isNumberValid = () => {
    const isNameValid = number && isvalidNumber(number)
    setPatternValidNumber(isNameValid ? '' : 'Should consist 10-digit Number')
  }
  
  

    function handleSubmit(event) {
        event.preventDefault()

        if(patternValidFirstName || patternValidLastName || patternValidNumber || patternValidE){
            return;
        }

        const patient = {
            firstName: fname,
            lastName: lname,
            email,
            address,
            phone: number,
            disease: disease
        }

        console.log("Patient " + JSON.stringify(patient));

        fetch("http://localhost:8080/api/v1", {
            method: "POST",
            body: JSON.stringify(patient),
            headers: {
                "Content-type": "application/json"
            }
        }).then(res => res.json()).then(data => {
            UsersData.saveUserData(data)

            swal({
                title : "Data Added Successfully",
                text : "Redirect to home page",
                icon : "success",
            }).then(val=>{
                console.log("Ok Clicked");
                navigate("/home")
            })

        }).catch(err => {
            console.log("Some Error")
            if (!navigator.onLine) {
                console.log("inside offline mode");
                // UsersData.getLastId();
                const newPatient = {
                    id:Math.floor(Math.random()*100),
                    firstName : patient.firstName,
                    lastName : patient.lastName,
                    email : patient.email,
                    address : patient.address,
                    phone : patient.phone,
                    disease : patient.disease
                }
                console.log("The patient is " + JSON.stringify(newPatient));
                UsersData.saveNewUserData(newPatient).then(data => {
                   // UsersData.saveUserData(newPatient)

                    swal({
                        title : "Data Added Successfully",
                        text : "Redirect to home page",
                        icon : "success",
                    }).then(val=>{
                        console.log("Ok Clicked");
                        navigate("/home")
                    })
                }).catch(err => {
                    seterror("Something Went Wrong!!")

                })


            }
            else {
                console.log(err);
                swal({
                    title : "Something Went Wrong",
                    text : "Unable to connect to server",
                    icon : "error",
                }).then(val=>{
                    console.log("Ok Clicked");
                    navigate("/home")
                })
            }

        })
    }

    return (
        <div className="container h-100">

            <div className="row">
                <div className="col-md-8 mx-auto m-5">
                    <Navbar></Navbar>
                    <div className={`card mt-5 ${styles.form}`} >

                        <div className="card-body">
                            <form onSubmit={handleSubmit}>
                                <div className="form-group">
                                    <label htmlFor="firstName">First Name </label>
                                    <input 
                                        type="text" 
                                        id="firstName"
                                        onChange={handleFName} 
                                        onBlur={isFirstNameValid}
                                        onFocus={()=>{
                                            setPatternValidFirstName("should contain letters only")
                                        }}
                                        className="form-control" required></input>
                                    <div className="form-text text-danger"> {patternValidFirstName}</div>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="">Last Name </label>
                                    <input type="text" onChange={handleLName}
                                        onBlur={isLastNameValid}
                                        onFocus={()=>{
                                            setPatternValidLastName("should contain letters only")
                                        }}
                                        className="form-control" required></input>
                                        <div className="form-text text-danger"> {patternValidLastName}</div>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="">Email Id </label>
                                    <input type="email" onChange={handleEmail} 
                                            onBlur={isEmailValid}
                                            onFocus={()=>{
                                            setPatternValidE("Eg. abc@gmail.com")
                                        }}
                                        className="form-control" required></input>
                                        <div className="form-text text-danger"> {patternValidE}</div>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="">Number </label>
                                    <input type="number" onChange={handleNumber} 
                                        onBlur={isNumberValid}
                                        onFocus={()=>{
                                            setPatternValidNumber("should be 10-digit number.")
                                        }}
                                        className="form-control" required ></input>
                                        <div className="form-text text-danger"> {patternValidNumber}</div>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="">Disease </label>
                                    <input type="text" onChange={handleDisease} className="form-control" required></input>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="">Address </label>
                                    <textarea className="form-control" onChange={handleAddress} rows={2} required></textarea>
                                </div>
                                {error && <p className="text-center text-warning font-weight-bold">{error}</p>}
                                <br></br>
                                <input  type="submit" value="Add Patient" className={`${styles.addbutton} btn btn-outline-primary btn-block`}></input>
                                <br/>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default AddPatient;